<!-- //session_start(); -->

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<form class = "" action = "" method="post">
<div class="fixed-header">
	<div class = "container">
		<div class="header">
			<div style="float:left; color:white;margin-left: -10px;margin-top:25px;">
				<img border="0"  src="../images/rotary.png" style=" margin-top: 82;width:270;margin-left:-120;height:100;">
				
			</div>
		</div>
	</div>
	<div align="right" style="margin-top: -60px; margin-right: 26px;">
         <button type="submit" class="btn btn-info" name = "logout"> Logout </button>
    </div>
</div>
</form>
<?php
 
 if (isset($_POST['logout'])) 
 {
 	ob_start();
 	session_unset();
 	echo $_SESSION['user_name'];
 	session_destroy();
 	if(empty($_SESSION['user_name']))
 	{
 		//echo "<script>location='http://rid3190.zenopsys.in/index.php'</script>";
 		echo "<script>location='http://localhost/RotaryApp/index.php'</script>";
  	}
 }
