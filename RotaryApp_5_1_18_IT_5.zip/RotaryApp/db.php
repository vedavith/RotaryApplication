        <?php	
        	$server=mysql_connect("localhost","root","");
			$connect=mysql_select_db("rotary",$server);
        ?>
