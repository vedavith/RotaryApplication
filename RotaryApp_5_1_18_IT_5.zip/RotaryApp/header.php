

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<div class="fixed-header">
<div class = "container">
<div class="header">
<div style="float:left; color:white;margin-left: 95px;margin-top: -33px;"><img border="0"  src="rotary.png" style=" margin-top: 52;width: 270;margin-left: -120;height: 100; "></div>
   


    <!--a href="logout.php" style="color:#f05b1c;float:right;margin-right: 50px;margin-top:5px;font-size:15px">LOGOUT<!--<img src="../images/log.png" style="width:30px;height:25px;float:right;margin-right: 69px;margin-top:0px;">></a>
    <a href="cart.php" style="color:#f05b1c;float:right;margin-right: 50px;margin-top:5px;font-size:15px">CART<!--<img src="../images/cart.png" style="width:30px;height:26px;float:right;margin-right: 50px;margin-top:0px;">></a-->
</div>

</div>
</div>

