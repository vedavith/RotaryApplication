<html>
	<head>
		
		<title>Rotary District Projects</title>

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

		  <link rel="stylesheet"  href="../css/styles.css">
		  <link rel="stylesheet"  href="../css/style.css">
			

	</head>
	<?php
		$server=mysql_connect("localhost","root","");
		$connect=mysql_select_db("rotary",$server);
	?>

	<?php
			include '../header.php';
			include '../footer.php';
			include '../header1.php';
	?>

   <body>
	<div class = "container">	
	<form action = "" method ="post">

	<div class = "" style="width: 400;height: 200;margin-top: 107px;background-color: #d1d1d1;padding:12px;margin-left: 35%;" align = "center">
		
	<div class = "" allign = "center">		
		<label>User Name</label> &nbsp;
		<input type = "text" name = "username" class = "" placeholder="User Name" id = "" required><br><br>
		<label>Password</label>	&nbsp;
		<input type = "text" name = "password" class = ""  placeholder="Password" id = "" required><br><br>

	</div>	
		<div class = "button" allign = "center">
		<button type = "submit" name = "submit" class = "" id = "">Submit</button>
		<div>
	</div> 
	</form>
	</div>
   </body>
	
</html>
<?php
if(isset($_POST['submit'])){

 $pass = base64_encode ($_POST['password']);	
 $sql = 'INSERT INTO `user`(User_name,Password)VALUES("'.$_POST['username'].'","'.$pass.'");';
	$query = mysql_query($sql);
	echo $sql;
	header('Location:http://localhost/RotaryApp/home/login.php');
}
?>
