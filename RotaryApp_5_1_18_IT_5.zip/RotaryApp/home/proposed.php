<?php 
session_start();
include'../db.php'; ?>
<!DOCTYPE html>
<html>
<head>
<title>Proposed Projects</title>

	<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	
	
	<link rel="stylesheet" href="../css/style.css">
	




</head>
<?php
			include '../headersearch.php';
			include '../footer1.php';
			include '../header2.php';
		?>

<body>

<div class="nav">
<div id="header_B2">

	

<form class="form-inline" method="post" action=" " style = "height: 4000px;">

<div align="center"> 
<button class= "btn btn-danger btn-lg" name = "cancel" style="margin-left: 90%; margin-top: 3%;"> BACK </button></div>

	<div align="center" ><h2 class="text-primary" style="color: #1c4680;"> Project 1 : Swarnamukhi Diagnostic and Healthcare center  </h2></br></div>

	<div class="form-group" style="border: 1px solid black;margin-left: 30%;background-color: rgb(209, 209, 209);height: 290px;width: 870px;margin-left: 20%;padding: -15px;">
			<table class="table table-responsive"> 
				<div class="form-group" style="margin-top: -12px;">
	<tr>
    
		<div class="form-group">
		<td> Host club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;" value="" disabled>Rotary Bangalore Lakeside</textarea></td></tr><br><br></div>
		<div class="form-group">
		<tr><td> International District</td>  <td>:</td><td><textarea style="margin-bottom: 11px;"  value="" disabled><?php echo "";?></textarea></td></div>
			
				<div class="form-group">
				<td>Project Budget</td>  <td>:</td><td><input type="text" value="<?php echo "54000USD"; ?>" disabled></td>

			</tr></div> 
   </table>
</div>


 <div align="center" ><h2 class="text-primary" style="color: #1c4680;"> Project 2 : Treatment to Children Suffering From Cancer   </h2></br></div>

	<div class="form-group" style="border: 1px solid black;margin-left: 30%;background-color: rgb(209, 209, 209);height: 290px;width: 870px;margin-left: 20%;padding: -15px;">
			<table class="table table-responsive"> 
				<div class="form-group" style="margin-top: -12px;">
	<tr>
    
		<div class="form-group">
		<td> Host club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;" value="" disabled>-Rotary Bangalore South West</textarea></td></tr><br><br></div>
		<div class="form-group">
		<tr><td> International District</td>  <td>:</td><td><textarea style="margin-bottom: 11px;"  value="" disabled><?php echo "";?></textarea></td></div>
			
				<div class="form-group">
				<td>Project Budget</td>  <td>:</td><td><input type="text" value="<?php echo "75000USD"; ?>" disabled></td>

			</tr></div> 
   </table>
</div>

<div align="center" "><h2 class="text-primary" style="color: #1c4680;"> Project 3 : provide mobile vehicle to screen eyes of the citizens of Bangalore and provide treatment according to the diagnosis  </h2></br></div>

	<div class="form-group" style="border: 1px solid black;margin-left: 30%;background-color: rgb(209, 209, 209);height: 290px;width: 870px;margin-left: 20%;padding: -15px;">
			<table class="table table-responsive"> 
				<div class="form-group" style="margin-top: -12px;">
	<tr>
    
		<div class="form-group">
		<td> Host club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;" value="" disabled>Rotary Bangalore Cubbonpark </textarea></td></tr><br><br></div>
		<div class="form-group">
		<tr><td> International District</td>  <td>:</td><td><textarea style="margin-bottom: 11px;"  value="" disabled><?php echo "";?></textarea></td></div>
			
				<div class="form-group">
				<td>Project Budget</td>  <td>:</td><td><input type="text" value="<?php echo "yet to finalize"; ?>" disabled></td>

			</tr></div> 
   </table>
</div>

<div align="center"><h2 class="text-primary" style="color: #1c4680;"> Project 4 : Setting up of Dialysis Centre  </h2></br></div>

	<div class="form-group" style="border: 1px solid black;margin-left: 30%;background-color: rgb(209, 209, 209);height: 290px;width: 870px;margin-left: 20%;padding: -15px;">
			<table class="table table-responsive"> 
				<div class="form-group" style="margin-top: -12px;">
	<tr>
    
		<div class="form-group">
		<td> Host club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;" value="" disabled>Rotary Bangalore South West</textarea></td></tr><br><br></div>
		<div class="form-group">
		<tr><td> International District</td>  <td>:</td><td><textarea style="margin-bottom: 11px;"  value="" disabled><?php echo "";?></textarea></td></div>
			
				<div class="form-group">
				<td>Project Budget</td>  <td>:</td><td><input type="text" value="<?php echo "75000USD"; ?>" disabled></td>

			</tr></div> 
   </table>
</div>

<div align="center"><h2 class="text-primary" style="color: #1c4680;"> Project 5 : Toilet Project  </h2></br></div>

	<div class="form-group" style="border: 1px solid black;margin-left: 30%;background-color: rgb(209, 209, 209);height: 290px;width: 870px;margin-left: 20%;padding: -15px;">
			<table class="table table-responsive"> 
				<div class="form-group" style="margin-top: -12px;">
	<tr>
    
		<div class="form-group">
		<td> Host club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;" value="" disabled>Rotary Bangalore Indiranagar </textarea></td></tr><br><br></div>
		<div class="form-group">
		<tr><td> International District</td>  <td>:</td><td><textarea style="margin-bottom: 11px;"  value="" disabled><?php echo "";?></textarea></td></div>
			
				<div class="form-group">
				<td>Project Budget</td>  <td>:</td><td><input type="text" value="<?php echo "1200000USD"; ?>" disabled></td>

			</tr></div> 
   </table>
</div>

<div align="center" ><h2 class="text-primary" style="color: #1c4680;"> Project 6 : Renovation of Anganavadi  </h2></br></div>

	<div class="form-group" style="border: 1px solid black;margin-left: 30%;background-color: rgb(209, 209, 209);height: 290px;width: 870px;margin-left: 20%;padding: -15px;">
			<table class="table table-responsive"> 
				<div class="form-group" style="margin-top: -12px;">
	<tr>
    
		<div class="form-group">
		<td> Host club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;" value="" disabled>Rotary Bangalore Indiranagar </textarea></td></tr><br><br></div>
		<div class="form-group">
		<tr><td> International District</td>  <td>:</td><td><textarea style="margin-bottom: 11px;"  value="" disabled><?php echo "";?></textarea></td></div>
			
				<div class="form-group">
				<td>Project Budget</td>  <td>:</td><td><input type="text" value="<?php echo "yet to finalize"; ?>" disabled></td>

			</tr></div> 
   </table>
</div>

<div align="center" ><h2 class="text-primary" style="color: #1c4680;"> Project 7 : Poviding Neo Natal Intensive care at Adichunchanagiri Hospital </h2></br></div>

	<div class="form-group" style="border: 1px solid black;margin-left: 30%;background-color: rgb(209, 209, 209);height: 290px;width: 870px;margin-left: 20%;padding: -15px;">
			<table class="table table-responsive"> 
				<div class="form-group" style="margin-top: -12px;">
	<tr>
    
		<div class="form-group">
		<td> Host club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;" value="" disabled>-Rotary Bangalore Banashankari </textarea></td></tr><br><br></div>
		<div class="form-group">
		<tr><td> International District</td>  <td>:</td><td><textarea style="margin-bottom: 11px;"  value="" disabled><?php echo "";?></textarea></td></div>
			
				<div class="form-group">
				<td>Project Budget</td>  <td>:</td><td><input type="text" value="<?php echo "500000 USD"; ?>" disabled></td>

			</tr></div> 
   </table>
</div>

<div align="center"><h2 class="text-primary" style="color: #1c4680;"> Project 8 : Rotary GIMS  Blood Bank   </h2></br></div>

	<div class="form-group" style="border: 1px solid black;margin-left: 30%;background-color: rgb(209, 209, 209);height: 290px;width: 870px;margin-left: 20%;padding: -15px;">
			<table class="table table-responsive"> 
				<div class="form-group" style="margin-top: -12px;">
	<tr>
    
		<div class="form-group">
		<td> Host club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;" value="" disabled>-Rotary Bangalore BGS </textarea></td></tr><br><br></div>
		<div class="form-group">
		<tr><td> International District</td>  <td>:</td><td><textarea style="margin-bottom: 11px;"  value="" disabled><?php echo "";?></textarea></td></div>
			
				<div class="form-group">
				<td>Project Budget</td>  <td>:</td><td><input type="text" value="<?php echo "1200000USD "; ?>" disabled></td>

			</tr></div> 
   </table>
</div>

<div align="center" ><h2 class="text-primary" style="color: #1c4680;"> Project 9 : Lab in a Box</h2></br></div>

	<div class="form-group" style="border: 1px solid black;margin-left: 30%;background-color: rgb(209, 209, 209);height: 290px;width: 870px;margin-left: 20%;padding: -15px;">
			<table class="table table-responsive"> 
				<div class="form-group" style="margin-top: -12px;">
	<tr>
    
		<div class="form-group">
		<td> Host club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;" value="" disabled>Rotary Indiranagar </textarea></td></tr><br><br></div>
		<div class="form-group">
		<tr><td> International District</td>  <td>:</td><td><textarea style="margin-bottom: 11px;"  value="" disabled><?php echo "";?></textarea></td></div>
			
				<div class="form-group">
				<td>Project Budget</td>  <td>:</td><td><input type="text" value="<?php echo " 35000USD "; ?>" disabled></td>

			</tr></div> 
   </table>
</div>




</form>
</div>
</body>
</html>
<?php
if(isset($_POST['cancel']))
{
	echo "<script>location='http://rid3190.zenopsys.in/home/home.php'</script>";	
}
?>