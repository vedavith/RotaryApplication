<?php
session_start();
@include '../db.php';
?>
<html>
	<head>
		
		<title>Rotary District Projects</title>
		

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		 <link rel="stylesheet"  href="../css/styles.css">
		  <link rel="stylesheet"  href="../css/style.css">
			


		</head>
	
	<?php
			include '../homeheader.php';
			include '../footer1.php';
			include '../header2.php';
	?>

	<form class = "" action = "" method ="post">
   <body>
	<div class = "container" align ="center">	
	
		<div class = "" style="width: 400;height: 280;margin-top: 50px;background-color: #d1d1d1;padding:70px;" align="left">
				
				<div class = "button" allign = "center">
		<button type = "submit" name = "dynamic" class = "btn btn-primary btn-lg" id = "">Previous Global Grants</button></div> <br><br>
	
				<div class = "button" allign = "center">
		<button type = "submit" name = "static" class = "btn btn-primary btn-lg" id = "">Proposed Global Grants </button> </div> 
		
	
	  </div>

	<div class = "" style="width: 400;height: 280;margin-top: -80px;margin-left: 900px;">

		<img src="../images/IMG.jpeg" style="height: 190px;width: 220px;"><br>
		<p>Suresh Hari</p> <p>DGE, RID 3190</p> <p> vishalbg@gmail.com</p>

	</div>

	</div>






	</body>
	</form>
</html>
<?php
if($_SESSION['user_name'] == 'admin')
{
//echo $_SESSION['user_name'];
	if(isset($_POST['static']))
	{
    
	echo "<script>location='http://rid3190.zenopsys.in/home/proposed.php'</script>";	
	//echo "<script>location='http:localhost/RotaryApp1/home/proposed.php'</script>";
	}
	
	if(isset($_POST['dynamic']))
	{
    echo "<script>location='http://rid3190.zenopsys.in/home/searchdisp.php'</script>";	
	//echo "<script>location='http:localhost/RotaryApp1/home/searchdisp.php'</script>";
	//header('Location:http:localhost/RotaryApp1/home/searchdisp.php');	
	}
}