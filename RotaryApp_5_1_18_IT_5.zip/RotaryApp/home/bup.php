<?php
if(isset($_POST['search']))
{
	$GrantId = $_POST['GrantId'];
	//$Club = $_POST['IntClub'];
	$sql1 = 'SELECT * FROM `sheet` WHERE Grant_Id = "'.$GrantId.'"';
	//$sql1 = 'SELECT * FROM `sheet`';
	$result = mysql_query($sql1);
    $i = '1';
    while($row = mysql_fetch_array($result)){
  ?> 
                                               
							<tbody class = "success">	                                
                                      <tr class="table table-hover"> 
                                        <td><?php echo $i;?></td>
                                        <td><?php echo $row['Grant_Id'];?></td>
                                        <td><?php echo $row['Program_Year'];?></td> 
                                        <td><?php echo $row['Host_Club'];?></td>
                                        <td><?php echo $row['International_Club'];?></td>
                                        <td><?php echo $row['International_District'];?></td>  
                                        <td><?php echo $row['Total_Budget'];?></td>
                                        <td> <button>View Details</button> </td>       
                                      </tr>                      
    							</tbody>
                                                 <?php 
                                                       $i++;
                                                      } 
                                                  }
                                                ?>