<!doctype HTML>

 <?php
session_start();	        			
@include "../db.php";                                        
?>

<html>
	<head>
		
		<title>Search and Display</title>
		
		

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		 
		  <link rel="stylesheet"  href="../css/style.css">
	</head>



		<?php
			include '../headersearch.php';
			include '../footer1.php';
			include '../header1.php';
		?>

               
	
	<body>
		<div class = "container">
		<!--div class = "form-group"-->
			<form class = "form-inline" action = "" method ="post">

			<!--div id = "table" align = "center" >
					<table class="table table-hover">
						
							<tr>
								<th><b> S.no <b></th>
                                <th><b> Grant Id <b></th>
								<th><b> Year <b></th>
								<th><b> Host Club <b></th>
								<th><b> International Club <b></th>
								<th><b> International District  <b></th>
                                <th><b>  Total Buget <b></th>
                                <th><b>  View Details <b></th>
							</tr>
						
					</table>
	</div-->
</form>
	</div>	
	</body>	
	

	
<div class = "container" align = "center">
	
	<div id = "table" align = "center" >
		
<table class="table table-hover" style="border:none;">

                                           
<?php
if($_SESSION['user_name'] == 'admin')
{
//echo $_SESSION['user_name']; 
if(isset($_GET['search']))
{
	//echo $_POST['GrantId'];
	echo "<thead> <tr>
								<th><b> S.no </b></th>
                                <th><b> Grant Id </b></th>
								<th><b> Year </b></th>
								<th><b> Host Club </b></th>
								<th><b> International Club </b></th>
								<th><b> International District  </b></th>
                                <th><b>  Total Buget </b></th>
                                <th><b>  View Details </b></th>
							</tr> </thead>  <tbody>  ";
	 echo "<p class = 'lead text-info'> You Searched '";
	 echo $_GET['IntDist'];
	 echo "'</p>"; 
	 
$sql1 = 'SELECT * FROM `sheet` where International_District= "'.$_GET['IntDist'].'"';
$result = mysql_query($sql1);
  //$row = mysql_fetch_array($result)
 	$i = '1';
  while($row = mysql_fetch_array($result)){
  
    	?>
                       

                                      <tr class="table table-hover info"> 
            				            <td><?php echo $i;?></td>
                                        <td><?php echo $row['Grant_Id'];?></td>
                                        <td><?php echo $row['Program_Year'];?></td> 
                                        <td><?php echo $row['Host_Club'];?></td>
                                        <td><?php echo $row['International_Club'];?></td>
                                        <td><?php echo $row['International_District'];?></td>  
                                        <td><?php echo $row['Total_Budget'];?></td>
                                        <td><div class = info><a name = "view" href="viewdet.php?id=<?php echo $row['Id'];?>">View Details</a></div></td>       
                                      </tr>                      
    							
            <?php                                     
    
    	$i++;
    }	
    }
?></tbody>
 </table>
</div></div>
<div class = "container" align = "center">
	
	<div id = "table" align = "center" >

 <table class="table table-hover">

<?php
echo "<thead> <tr>
								<th><b> S.no </b></th>
                                <th><b> Grant Id </b></th>
								<th><b> Year </b></th>
								<th><b> Host Club </b></th>
								<th><b> International Club </b></th>
								<th><b> International District  </b></th>
                                <th><b>  Total Buget </b></th>
                                <!--th><b>  View Details </b></th-->
							</tr> </thead>  <tbody>  ";


						$sql2 = 'SELECT * FROM `sheet` ';
						$result2 = mysql_query($sql2);
					    $j = '1';
					    while($row2 = mysql_fetch_array($result2)){
									    	?>
										                                
                                      <tr class="table table-hover"> 
                                        <td><?php echo $j;?></td>
                                        <td><?php echo $row2['Grant_Id'];?></td>
                                        <td><?php echo $row2['Program_Year'];?></td> 
                                        <td><?php echo $row2['Host_Club'];?></td>
                                        <td><?php echo $row2['International_Club'];?></td>
                                        <td><?php echo $row2['International_District'];?></td>  
                                        <td><?php echo $row2['Total_Budget'];?></td></tr>
                                       <!--td> <div class = info><a name = "view" href="viewdet.php?id=<?php //echo $row['Id'];?>">View Details</a></div></td>       
                                      </tr-->      
                                      <?php
                                      $j++;
                                  }
                              
?>
<?php
}
?>
</table></div></div>
                                                </html>
