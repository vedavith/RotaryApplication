<?php 
session_start();
include'../db.php'; ?>
<!DOCTYPE html>
<html>
<head>
<title>View Details</title>

	<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	
	
	<link rel="stylesheet" href="../css/style.css">
	


<style type="text/css">
	#td
	{
		width:"auto";
	}
</style>

</head>
<?php
			include '../headersearch.php';
			include '../footer1.php';
			include '../header2.php';
		?>

<body>

<?php
if($_SESSION['user_name'] == 'admin')
{
//echo $_SESSION['user_name'];
if(!empty($_GET['id']))
					{
		$sql='SELECT * FROM `sheet` WHERE Id="'.$_GET['id'].'" ';
		$query=mysql_query($sql);
		$row=mysql_fetch_array($query);
					}
?>

<div class="nav">
<div id="header_B2">
<form class="form-inline" method="post" action="">
	<div align="center" style="margin-top: 20px;"><h2 class="text-info"> Grant Id : <?php echo $row['Grant_Id']; ?></h2></br></div>

	<div class="form-group" style="border: 1px solid black;margin-left: 30%;margin-top: 30px;background-color: rgb(209, 209, 209);height: 290px;width: 870px;margin-left: 20%;padding: -15px;">
			<table class="table table-responsive"> 
				<div class="form-group" style="margin-top: -12px;">
	<tr>
		<td>Program Year </td> <td>:</td><td><input type="text"   value=" <?php echo $row['Program_Year']; ?>" disabled></td> </div>
    
		<div class="form-group">
		<td> Host club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;" value="" disabled><?php echo $row['Host_Club']; ?></textarea></td></tr><br><br></div>
		<div class="form-group">
		<tr><td> International Club </td>  <td>:</td><td><textarea style="margin-bottom: 11px;"  value="" disabled><?php echo $row['International_Club']; ?></textarea></td></div>
			
				<div class="form-group">
				<td>Total Budget</td>  <td>:</td><td><input type="text" value="<?php echo $row['Total_Budget']; ?>" disabled></td>

			</tr></div> 
   </table>
</div>


	<div align="center" style="margin-top: 20px;"><h2 class="text-primary" > Project Details</h2></br></div>

	<div class = "form-group" style="border: 1px solid black;margin-left: 30%;margin-top: 20px;background-color: rgb(209, 209, 209);height: 120px;width: 870px;margin-left: 20%;padding: 15px;">
	<table  id="viewtab"> 
	<tr>
		<th>Project Details</th>                                                                          
	</tr>
	    <tr>
		<td><textarea class="" value="" style="width: 382%;" disabled="disabled"><?php  echo $row['Project_Description'];?></textarea> </td> 
	</tr>

   </table>
</div>



<div>
<button class= "btn btn-danger btn-lg" name = "cancel" style="margin-left: 50%; margin-top: 3%;"> Cancel </button>
</form>
</div>
</body>
</html>
<?php 
}
?>
<?php

if(isset($_POST['cancel']))
{
	echo "<script>location='http://rid3190.zenopsys.in/home/searchdisp.php'</script>";	
}
?>