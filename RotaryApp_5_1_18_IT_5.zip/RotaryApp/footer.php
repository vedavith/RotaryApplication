<div class="fixed-footer">
		
		<div style="float:right;padding-right:100px; "><a href="http://zenopsys.com/"><img src="images/zenopsys.png" width="75" height="30" ></a></div>
<div style="float:right; margin-top:10px;margin-right: 977px;;color:#ed9f3b;font-size:15px;font-weight:bold;" align="left">COPYRIGHT &copy; 2017</div> 
</div> 


