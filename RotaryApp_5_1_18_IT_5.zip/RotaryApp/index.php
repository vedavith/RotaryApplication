<?php
session_start();
include 'db.php';
?>
<?php
		$query = 'SELECT * FROM `user`';
		$result = mysql_query($query);
		$row = mysql_fetch_array($result);
	?>

<?php
            //include 'header.php';
            include 'footer.php';
            //include 'header2.php';
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login </title>
  <!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
		<link rel="stylesheet" href="css/login.css">

		  <link rel="stylesheet"  href="css/style.css">
<style>

		/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 200px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    position: relative;
    background-color: #ffffff;
    margin: 0px 497px;
    padding: 0;
    border: 1px solid #888;
    width: 35%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
    from {top:-300px; opacity:0}
    to {top:0; opacity:1}
}

@keyframes animatetop {
    from {top:-300px; opacity:0}
    to {top:0; opacity:1}
}

/* The Close Button */
.close {
    color: white;
    float: right;
    font-size: 40px;
    font-weight: bold;
	margin:-10px;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}

.modal-header {
    padding: 12px 16px;
    background-color: #f05b1c;
    color: white;
	font-size: 20px;
	font-family: 'Titillium Web', sans-serif;
}

.modal-body {color: black;height:190px;padding: 12px 16px;background:rgba(10, 19, 25, 0.9)}

.modal-footer {
    padding: 12px 16px;
    background-color: #f05b1c;
    color: white;
	font-size: 20px;
	font-family: 'Titillium Web', sans-serif;
}
@media only screen  and (max-width: 1600px) {
.donor{
border: 1px solid;
    color: white;
    float: right;
    height: 205px;
   width: 330px;
    padding: 5px;

}
}
.donatebtn {
    border: 0;
    outline: none;
    border-radius: 0;
    padding: 15px 0;
    font-size: 20px;
    cursor: pointer;
    text-transform: uppercase;
    background: #f05b1c;
    color: #ffffff;
    -webkit-transition: all 0.5s ease;
    transition: all 0.5s ease;
    -webkit-appearance: none;
}
</style>

</head>

<body>

  </p></br></br>
                 
	<div class="form">

		<div class="tab-content">
			<div align="center">
			<img border="0"  src="rotary.png" style=" margin-top:-31px;width:270;margin-left:-10;height:100;">
		</div>
		<!-- <ul class="tab-group">
			<li class="tab-active">
				<a href="#"> Rotary Login </a>
			</li>			
		</ul> -->
			<!--div id="login" style="margin-top: 30px;">
			           <h1 class="text text-warning" style="font-size: 25px;">LOGIN</h1> </div><br-->
			 <form  action="" method="post">

				<div class="field-wrap">
				<!-- <label><span class="req"></span></label> -->
				<input type="text" name="username" style="margin-top: 50px;" value="<?php echo $row['User_name'];?>" required autocomplete="off" disabled = "disabled"/>
				</div>

				<div class="field-wrap">
				<label> Password<span class="req">*</span></label>
				<input type="password" name="password" value="" required autocomplete="off"/>
				</div>
				<div>
					<button type="submit" class="btn btn-primary btn-lg" name="submit" style="margin-left: 40%;"> LOGIN </button>
				</div>
				
			  </form>

			</div>

			<div id="login">   			</div>

		</div>


	<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script  src="js/index.js"></script>
    <script>
	// Get the modal
	var modal = document.getElementById('myModal');

	// Get the button that opens the modal
	var btn = document.getElementById("myBtn");

	// Get the <span> element that closes the modal
	var span = document.getElementsByClassName("close")[0];

	// When the user clicks the button, open the modal
	btn.onclick = function() {
		modal.style.display = "block";
	}

	// When the user clicks on <span> (x), close the modal
	span.onclick = function() {
		modal.style.display = "none";
	}

	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
		if (event.target == modal) {
			modal.style.display = "none";
		}
	}
	</script>

</body>
</html>
<?php
$user_name = $row['User_name'];
//echo $user_name." this is from row value\n";

$_SESSION['user_name'] = $user_name;
//echo $_SESSION['user_name']." This is session value";

if(isset($_POST['submit'])){
     
     if($_SESSION['user_name'] == 'admin'){
	if((base64_decode($row['Password']) == $_POST['password']))
	{
		//echo "<script>location='http://localhost/RotaryApp/home/home.php'</script>";
		echo "<script>location='http://rid3190.zenopsys.in/home/home.php'</script>";	
	}
	else
	{
		echo "<script>window.alert('Wrong Credentials!!');</script>";
	} 
       }
}

