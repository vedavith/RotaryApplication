<html>

                <!-- Latest compiled and minified CSS -->
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- jQuery library -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- Latest compiled JavaScript -->
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<style>
  .btn-info, .btn-info:hover, .btn-info:active, .btn-info:visited {
    background-color: #1c4680;
}
</style>
<body>
<div class="fixed-header1" style="height:0px;">                
<!--div style="float:left; color:white;margin-left: 95px;
    margin-top: -33px;"><img border="0"  src="" width="130" height="75"></div-->
   
   

<!--div style="color: white;
    font-size: 32px;
    /* margin-right: -6706px; */
    margin-top: -18px;
    margin-left: 261px;"><b>ROTARY DISTRICT 3190<br>
</b></div-->
</div>

</body>
</html>
